vim -p KernelFunctions.gex Kernel.gex utils.gex
#vim -p BootLoader.gex ProtectedMode.gex Redirect.gex KernelFunctions.gex Kernel.gex utils.gex
