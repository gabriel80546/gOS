#!/bin/zsh
vim -p 4.KernelFunctions.gex 5.Kernel.gex utils.gex memMap.txt
