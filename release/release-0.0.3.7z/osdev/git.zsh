#!/bin/zsh
git config --global user.email "gabriel80546@gmail.com"
git config --global user.name "gabriel80546"
git add --all
git commit -am "asdfasdfijwer"
git push
