*STACK+1 = pKEY*
*STACK+2 = pKEYFINAL*
*STACK+3 = cursor*
